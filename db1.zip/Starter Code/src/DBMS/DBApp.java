package DBMS;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class DBApp {
    static int dataPageSize = 2;

    public static void createTable(String tableName, String[] columnsNames) {
        String path = FileManager.class.getResource("FileManager.class").toString();
        File directory = new File(path.substring(6, path.length() - 17) + File.separator + "Tables" + File.separator);
        File tableDirectory = new File(directory, tableName);

        if (tableDirectory.exists()) {
            System.out.println("A table with the same name already exists");
            return;
        }

        Table createdTable = new Table(tableName, columnsNames);
        createdTable.logOperation("Table created name :"+ tableName + ", columnsNames :"+ Arrays.toString(columnsNames));
        
        boolean isCreated = FileManager.storeTable(tableName, createdTable); 
        if (isCreated) {
            System.out.println("Table " + tableName + " is created successfully.");
             
        } else {
            System.out.println("There was an error creating table " + tableName + ".");
        }
    }

    public static void insert(String tableName, String[] record) {
        Table table = FileManager.loadTable(tableName);

        if (table == null) {
            System.out.println("The table you're trying to insert in does not exist.");
            return;
        }
        long start = System.currentTimeMillis();
        ArrayList<Page> pages = table.getPages();
        int pageNumber= -1;
        boolean inserted = false;
        for (Page page : pages) {
            if (page.AvailableSpace()) {
                page.insertInPage(record);
                pageNumber = page.getPageNumber();
                FileManager.storeTablePage(tableName, page.getPageNumber(), page);
                inserted = true;
                break;
            }
        }

        if (!inserted) {
            int newPageNumber = pages.size();
            Page newPage = new Page(new ArrayList<>(), newPageNumber);
            newPage.insertInPage(record);
            pages.add(newPage);
            table.setPages(pages); 
            pageNumber = newPageNumber;

            FileManager.storeTablePage(tableName, newPageNumber, newPage);
        }
        long end = System.currentTimeMillis(); 
        long duration = end - start;
        table.logOperation("Inserted:"+Arrays.toString(record)+" at page number:"+pageNumber + ", execution time (mil): " + duration); 
        FileManager.storeTable(tableName, table);
    }

    public static ArrayList<String[]> select(String tableName) {
        ArrayList<String[]> result = new ArrayList<>();
        Table table = FileManager.loadTable(tableName);
        if (table == null) {
            System.err.println("Table '" + tableName + "' not found.");
            return result;
        }
        long start = System.currentTimeMillis();
        int recordCount = 0;
        for (int i = 0; i < table.getPages().size(); i++) {
            Page page = FileManager.loadTablePage(tableName, i);
            if (page != null) {
                result.addAll(page.records);
                recordCount += page.records.size();
            }
        }
        long end = System.currentTimeMillis(); 
        long duration = end - start;
       
        
        table.logOperation("Select all pages:"+ table.getPages().size() +
                ", records:"+recordCount + ", execution time (mil):"+duration);


        FileManager.storeTable(tableName, table);
        return result;
    }

    public static ArrayList<String[]> select(String tableName, int pageNumber, int recordNumber) {
        ArrayList<String[]> result = new ArrayList<>();
        Table table = FileManager.loadTable(tableName);

        Page page = FileManager.loadTablePage(tableName, pageNumber);
        if (page == null || recordNumber < 0 || recordNumber >= page.records.size()) {
            System.err.println("Invalid page or record number.");
            return result;
        }
        
        long start = System.currentTimeMillis();
        result.add(page.records.get(recordNumber));
        long end = System.currentTimeMillis(); 
        long duration = end - start;
       
        
        table.logOperation("Select pointer page:" +pageNumber + ", record:"+recordNumber + ", total output count:"+result.size()+", execution time (mil):"+duration);

        FileManager.storeTable(tableName, table);
        return result;
    }


   
    public static ArrayList<String[]> select(String tableName, String[] cols, String[] vals) {
        ArrayList<String[]> result = new ArrayList<>();
        Table table = FileManager.loadTable(tableName);
        ArrayList<String> recordsPerPage = new ArrayList<>();
        
        if (table == null) {
            System.err.println("Table doesn't exist: " + tableName);
            return result;
        }

        long start = System.currentTimeMillis();
        ArrayList<Page> pages = table.getPages();
        String[] columnNames = table.getColoumns();
        int recordCount = 0;

        for (int pageIndex = 0; pageIndex < pages.size(); pageIndex++) {
            Page page = pages.get(pageIndex);
            int matchCountInPage = 0;

            for (String[] record : page.records) {
                boolean match = true;
                for (int i = 0; i < cols.length; i++) {
                    int colIndex = Arrays.asList(columnNames).indexOf(cols[i]);
                    if (colIndex == -1 || !record[colIndex].equals(vals[i])) {
                        match = false;
                        break;
                    }
                }
                if (match) {
                    result.add(record);
                    matchCountInPage++;
                    recordCount++;
                }
            }

            if (matchCountInPage > 0) {
                recordsPerPage.add("[" + pageIndex + ", " + matchCountInPage + "]");
            }
        }

        long end = System.currentTimeMillis();
        long duration = end - start;

        String perPageFormatted = "[" + String.join(", ", recordsPerPage) + "]";
      
        table.logOperation("Select condition:"+Arrays.toString(cols)+ "->" +Arrays.toString(vals)
                + ", records per page:"+perPageFormatted + ", records:"+recordCount + ", execution time (mil):"+duration);

        FileManager.storeTable(tableName, table);
        return result;
    }

    
    public static String getFullTrace(String tableName) {
        Table table = FileManager.loadTable(tableName);
        if (table == null) {
            return "Table not found: " + tableName;
        }

        ArrayList<String> traceActivity = table.getTraceLog();
        if (traceActivity == null || traceActivity.isEmpty()) {
            return "No operations logged for table: " + tableName;
        }
        ArrayList<Page> pages = table.getPages();
        int totalPages = pages.size();
        int totalRecords = 0;

        int i = 0;
        while (i < totalPages) {
            totalRecords += pages.get(i).getRecords().size();
            i++;
        }

        ArrayList<String> traceCopy = new ArrayList<>(traceActivity);
        traceCopy.add("Pages Count: " + totalPages + ", Records Count: " + totalRecords);

        return String.join("\n", traceCopy);
    }

    public static String getLastTrace(String tableName) {
        Table table = FileManager.loadTable(tableName);
        if (table == null) return "";

        ArrayList<String> log = table.getTraceLog();
        if (log.isEmpty()) return "";

        return log.get(log.size() - 1);
    }
    	
    	public static void main(String []args) throws IOException 
    	 { 
    		String[] cols = {"id","name","major","semester","gpa"}; 
    		  createTable("student", cols); 
    		  String[] r1 = {"1", "stud1", "CS", "5", "0.9"}; 
    		  insert("student", r1); 
    		   
    		  String[] r2 = {"2", "stud2", "BI", "7", "1.2"}; 
    		  insert("student", r2); 
    		   
    		  String[] r3 = {"3", "stud3", "CS", "2", "2.4"}; 
    		  insert("student", r3); 
    		   
    		  String[] r4 = {"4", "stud4", "DMET", "9", "1.2"}; 
    		  insert("student", r4); 
    		   
    		  String[] r5 = {"5", "stud5", "BI", "4", "3.5"}; 
    		  insert("student", r5); 
    		   
    		   
    		        System.out.println("Output of selecting the whole table content:"); 
    		  ArrayList<String[]> result1 = select("student"); 
    		        for (String[] array : result1) { 
    		            for (String str : array) { 
    		                System.out.print(str + " "); 
    		            } 
    		            System.out.println(); 
    		        } 
    		         
    		        System.out.println("--------------------------------"); 
    		        System.out.println("Output of selecting the output by position:"); 
    		  ArrayList<String[]> result2 = select("student", 1, 1); 
    		        for (String[] array : result2) { 
    		            for (String str : array) { 
    		                System.out.print(str + " "); 
    		            } 
    		            System.out.println();  
    		        } 
    		         
    		        System.out.println("--------------------------------"); 
    		        System.out.println("Output of selecting the output by column condition:"); 
    		  ArrayList<String[]> result3 = select("student", new String[]{"gpa"}, new 
    		String[]{"1.2"}); 
    		        for (String[] array : result3) { 
    		 
    		 
    		            for (String str : array) { 
    		                System.out.print(str + " "); 
    		            } 
    		            System.out.println();  
    		        } 
    		        System.out.println("--------------------------------"); 
    		  System.out.println("Full Trace of the table:"); 
    		  System.out.println(getFullTrace("student")); 
    		  System.out.println("--------------------------------"); 
    		  System.out.println("Last Trace of the table:"); 
    		  System.out.println(getLastTrace("student")); 
    		  System.out.println("--------------------------------"); 
    		  System.out.println("The trace of the Tables Folder:"); 
    		  System.out.println(FileManager.trace()); 
    		  FileManager.reset(); 
    		  System.out.println("--------------------------------"); 
    		  System.out.println("The trace of the Tables Folder after resetting:"); 
    		  System.out.println(FileManager.trace()); 
    		   
    		   
    		 } 
    	  
    	 }