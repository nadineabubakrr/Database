
package DBMS;
import java.io.Serializable;
import java.util.HashMap;

public class BitmapIndex implements Serializable {
    private HashMap<String, String> index;

    public BitmapIndex() {
        this.index = new HashMap<>();
    }

    public void addValue(String value, String bitstream) {
        index.put(value, bitstream);
    }

    public String getBitstream(String value) {
        return index.getOrDefault(value, "");
    }

    public HashMap<String, String> getIndex() {
        return index;
    }
}